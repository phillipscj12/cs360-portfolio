package com.example.helloapp_chrisphillips

data class WeightItem(
    val id: Long,
    val weight: Float,
    val date: Long
)
