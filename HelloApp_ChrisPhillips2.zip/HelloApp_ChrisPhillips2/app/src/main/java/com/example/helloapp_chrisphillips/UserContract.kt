package com.example.helloapp_chrisphillips

object UserContract {
    const val TABLE_NAME     = "users"
    const val COLUMN_ID      = "_id"
    const val COLUMN_USER    = "username"
    const val COLUMN_PASS    = "password"

    // SQL to create the table
    const val CREATE_TABLE = """
        CREATE TABLE $TABLE_NAME (
          $COLUMN_ID   INTEGER PRIMARY KEY AUTOINCREMENT,
          $COLUMN_USER TEXT    NOT NULL UNIQUE,
          $COLUMN_PASS TEXT    NOT NULL
        );
    """
}
