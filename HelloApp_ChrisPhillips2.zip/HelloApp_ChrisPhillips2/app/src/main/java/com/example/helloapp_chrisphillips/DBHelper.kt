package com.example.helloapp_chrisphillips

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context)
    : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME    = "weight_tracker.db"
        private const val DB_VERSION = 1

        // user table
        const val TABLE_USER   = "user"
        const val COL_USER_ID  = "user_id"
        const val COL_USERNAME = "username"
        const val COL_PASSWORD = "password"

        // weight table
        const val TABLE_WEIGHT     = "weight"
        const val COL_WEIGHT_ID    = "weight_id"
        const val COL_USER_FK      = "user_id"
        const val COL_DATE         = "entry_date"
        const val COL_WEIGHT_VALUE = "weight_value"

        // Create user table SQL
        private const val SQL_CREATE_USER = """
      CREATE TABLE $TABLE_USER (
        $COL_USER_ID   INTEGER PRIMARY KEY AUTOINCREMENT,
        $COL_USERNAME  TEXT NOT NULL,
        $COL_PASSWORD  TEXT NOT NULL
      );
    """

        // Create weight table SQL
        private const val SQL_CREATE_WEIGHT = """
      CREATE TABLE $TABLE_WEIGHT (
        $COL_WEIGHT_ID    INTEGER PRIMARY KEY AUTOINCREMENT,
        $COL_USER_FK      INTEGER NOT NULL,
        $COL_DATE         TEXT    NOT NULL,
        $COL_WEIGHT_VALUE REAL    NOT NULL,
        FOREIGN KEY($COL_USER_FK)
          REFERENCES $TABLE_USER($COL_USER_ID)
      );
    """
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_USER)
        db.execSQL(SQL_CREATE_WEIGHT)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Drop & recreate on version bump
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHT")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USER")
        onCreate(db)
    }
}
