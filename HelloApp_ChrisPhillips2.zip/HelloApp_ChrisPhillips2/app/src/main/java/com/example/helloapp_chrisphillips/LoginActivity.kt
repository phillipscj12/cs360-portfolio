package com.example.helloapp_chrisphillips

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.content.ContentValues
import com.example.helloapp_chrisphillips.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val user = binding.etUsername.text.toString()
            val pass = binding.etPassword.text.toString()
            if (user.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "Fill both fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val values = ContentValues().apply {
                put(UserContract.COLUMN_USER, user)
                put(UserContract.COLUMN_PASS, pass)
            }
            val db = MyDbHelper(this).writableDatabase
            db.insert(UserContract.TABLE_NAME, null, values)
            db.close()

            // then navigate to DashboardActivity…
        }
    }
}
