package com.example.helloapp_chrisphillips

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

private const val DB_NAME    = "helloapp.db"
private const val DB_VERSION = 1

class MyDbHelper(context: Context)
    : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        // create users table
        db.execSQL(UserContract.CREATE_TABLE)
        // create weights table
        db.execSQL(WeightContract.CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // drop old tables
        db.execSQL("DROP TABLE IF EXISTS ${UserContract.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${WeightContract.TABLE_NAME}")
        // recreate
        onCreate(db)
    }
}
