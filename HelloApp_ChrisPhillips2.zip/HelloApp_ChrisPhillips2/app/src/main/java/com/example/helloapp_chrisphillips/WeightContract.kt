package com.example.helloapp_chrisphillips

object WeightContract {
    const val TABLE_NAME      = "weights"
    const val COLUMN_ID       = "_id"
    const val COLUMN_WEIGHT   = "weight_value"
    const val COLUMN_DATE     = "timestamp"

    const val CREATE_TABLE = """
        CREATE TABLE $TABLE_NAME (
          $COLUMN_ID     INTEGER PRIMARY KEY AUTOINCREMENT,
          $COLUMN_WEIGHT REAL    NOT NULL,
          $COLUMN_DATE   INTEGER NOT NULL
        );
    """
}
