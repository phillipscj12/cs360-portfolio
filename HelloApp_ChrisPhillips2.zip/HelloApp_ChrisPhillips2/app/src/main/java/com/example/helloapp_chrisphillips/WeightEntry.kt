package com.example.helloapp_chrisphillips

data class WeightEntry(
    val id: Int,
    val date: String,
    val weight: Float
)
