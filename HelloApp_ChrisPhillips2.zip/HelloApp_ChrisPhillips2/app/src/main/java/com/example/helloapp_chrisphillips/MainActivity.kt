package com.example.helloapp_chrisphillips

import android.content.ContentValues
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.helloapp_chrisphillips.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: WeightAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1) Configure RecyclerView
        binding.rvWeights.layoutManager = LinearLayoutManager(this)
        adapter = WeightAdapter(loadAllWeights())
        binding.rvWeights.adapter = adapter

        // 2) Handle “Add” button
        binding.btnAdd.setOnClickListener {
            val txt = binding.etWeight.text.toString()
            if (txt.isBlank()) {
                Toast.makeText(this, "Enter a weight", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val w = txt.toFloat()

            // 3) Insert into DB
            val values = ContentValues().apply {
                put(WeightContract.COLUMN_WEIGHT, w)
                put(WeightContract.COLUMN_DATE, System.currentTimeMillis())
            }
            MyDbHelper(this).writableDatabase.use { db ->
                db.insert(WeightContract.TABLE_NAME, null, values)
            }

            // 4) Reload fresh data
            adapter.update(loadAllWeights())

            // 5) Clear input
            binding.etWeight.text?.clear()
        }
    }

    /**
     * Helper that queries SQLite and returns every row as a WeightItem,
     * sorted newest→oldest by date.
     */
    private fun loadAllWeights(): List<WeightItem> {
        val list = mutableListOf<WeightItem>()
        MyDbHelper(this).readableDatabase.use { db ->
            val cursor = db.query(
                WeightContract.TABLE_NAME,
                arrayOf(
                    WeightContract.COLUMN_ID,
                    WeightContract.COLUMN_WEIGHT,
                    WeightContract.COLUMN_DATE
                ),
                null, null, null, null,
                "${WeightContract.COLUMN_DATE} DESC"
            )
            with(cursor) {
                while (moveToNext()) {
                    list += WeightItem(
                        id     = getLong(0),
                        weight = getFloat(1),
                        date   = getLong(2)
                    )
                }
                close()
            }
        }
        return list
    }
}
