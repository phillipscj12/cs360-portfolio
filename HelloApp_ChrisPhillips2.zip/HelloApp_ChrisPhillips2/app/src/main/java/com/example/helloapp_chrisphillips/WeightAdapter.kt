package com.example.helloapp_chrisphillips

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.helloapp_chrisphillips.databinding.ItemWeightBinding

class WeightAdapter(
    private var items: List<WeightItem>
) : RecyclerView.Adapter<WeightAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemWeightBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemWeightBinding.inflate(
                LayoutInflater.from(parent.context),
                parent, false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val w = items[position]
        holder.binding.tvWeight.text = w.weight.toString()
        holder.binding.tvDate.text   = java.text.DateFormat
            .getDateTimeInstance()
            .format(w.date)
    }

    override fun getItemCount() = items.size

    /** helper to swap in a new list */
    fun update(newList: List<WeightItem>) {
        items = newList
        notifyDataSetChanged()
    }
}
