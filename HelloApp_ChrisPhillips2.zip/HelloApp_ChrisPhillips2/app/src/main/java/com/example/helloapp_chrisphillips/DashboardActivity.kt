package com.example.helloapp_chrisphillips

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // content to draw behind status/navigation bars:
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContentView(R.layout.activity_dashboard)
    }
}
