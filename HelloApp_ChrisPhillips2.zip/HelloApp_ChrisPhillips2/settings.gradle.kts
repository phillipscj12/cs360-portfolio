pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

rootProject.name = "HelloApp_ChrisPhillips2"
include(":app")
